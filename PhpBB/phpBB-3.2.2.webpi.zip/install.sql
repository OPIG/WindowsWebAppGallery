/**********************************************************************/
/* Install.SQL                                                        */
/*                                                                    */
/*           NOTICE OF LICENSE                                        */
/* Copyright (C) Microsoft Corporation All rights reserved.           */
/*                                                                    */
/* This program is free software; you can redistribute it and/or      */
/* modify it under the terms of the                                   */
/* GNU General Public License version 2 as published by the           */
/* Free Software Foundation.                                          */
/* This program is distributed in the hope that it will be useful,    */
/* but WITHOUT ANY WARRANTY; without even the implied warranty        */
/* of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.            */
/* See the GNU General Public License for more details.               */
/*                                                                    */
/* You should have received a copy of the GNU General Public License  */
/* along with this program; if not, write to the                      */
/* Free Software Foundation, Inc., 59 Temple Place, Suite 330,        */
/* Boston, MA 02111-1307 USA                                          */
/**********************************************************************/
USE PlaceHolderForDbName$$


DROP PROCEDURE IF EXISTS add_user $$

CREATE PROCEDURE add_user()
BEGIN
DECLARE EXIT HANDLER FOR 1044 BEGIN END;
GRANT ALL PRIVILEGES ON PlaceholderForDbName.* to 'PlaceholderForDbUsername'@'PlaceholderForDbServer' IDENTIFIED BY 'PlaceholderForDbPassword';
FLUSH PRIVILEGES;
END
$$

CALL add_user() $$

DROP PROCEDURE IF EXISTS add_user $$
